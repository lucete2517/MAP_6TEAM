package com.example.account_book.Data

//-----------------------------------------------------------------------------------------------------------------------
//결제 방법 저장을 위한 Class
//PaymentMethodName = 이름 || Balance = 잔액
//-----------------------------------------------------------------------------------------------------------------------
class PaymentMethodClass(val PaymentMethodName : String, var Balance : Int) {
}