package com.example.account_book.Setting

import androidx.fragment.app.Fragment

class SettingFragment : Fragment() {

}