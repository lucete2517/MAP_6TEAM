package com.example.account_book.Data

data class CategoryClass (val CategoryName : String, val KeywordList : ArrayList<String> = ArrayList()) {
}