package com.example.account_book.Data

data class CategoryClass (val CategoryName : String, var Income : Int = 0, var Spend : Int = 0, val KeywordList : ArrayList<String> = ArrayList()) {
}
