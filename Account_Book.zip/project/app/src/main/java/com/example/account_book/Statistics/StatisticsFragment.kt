package com.example.account_book.Statistics

import androidx.fragment.app.Fragment

class StatisticsFragment : Fragment() {
}